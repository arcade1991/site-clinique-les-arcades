# Site Clinique Les Arcades - Starter

Ce projet est un squelette complet avec frontend (Next.js), backend (Express, Prisma) et PostgreSQL via Docker.

## Démarrage rapide

```bash
docker-compose up --build
```
