import Link from 'next/link'

export default function Home() {
  return (
    <main className="container mx-auto p-4">
      <h1 className="text-3xl font-bold">Clinique Les Arcades</h1>
      <p>Bienvenue — prends un rendez-vous en ligne ou découvre nos médecins.</p>
      <nav className="mt-4">
        <Link href="/medecins">Voir les médecins</Link>
      </nav>
    </main>
  )
}
