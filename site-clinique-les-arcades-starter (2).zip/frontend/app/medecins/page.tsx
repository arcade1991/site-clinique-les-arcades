'use client'

import { useEffect, useState } from 'react'

interface Medecin {
  id: string
  nom: string
  prenom: string
  specialite: string
  photoUrl?: string
}

export default function MedecinsPage() {
  const [medecins, setMedecins] = useState<Medecin[]>([])

  useEffect(() => {
    async function fetchMedecins() {
      try {
        const res = await fetch('http://localhost:4000/api/medecins')
        if (res.ok) {
          const data = await res.json()
          setMedecins(data)
        }
      } catch (err) {
        console.error('Erreur chargement médecins', err)
      }
    }
    fetchMedecins()
  }, [])

  return (
    <main className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Nos médecins</h1>
      <ul className="grid gap-4">
        {medecins.map(m => (
          <li key={m.id} className="border rounded p-4 shadow">
            <h2 className="text-xl font-semibold">{m.prenom} {m.nom}</h2>
            <p className="text-gray-700">{m.specialite}</p>
            {m.photoUrl && <img src={m.photoUrl} alt={`${m.nom}`} className="mt-2 w-32 h-32 object-cover rounded-full"/>}
          </li>
        ))}
      </ul>
    </main>
  )
}
