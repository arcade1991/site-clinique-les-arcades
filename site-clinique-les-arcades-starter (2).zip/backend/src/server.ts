import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import { json } from 'body-parser'

const app = express()
app.use(helmet())
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000' }))
app.use(json())

app.get('/api/health', (_req, res) => res.json({ ok: true }))

app.listen(process.env.PORT || 4000, () => console.log('Backend listening'))
