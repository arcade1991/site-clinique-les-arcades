import { Router } from 'express'
import { PrismaClient } from '@prisma/client'

const router = Router()
const prisma = new PrismaClient()

router.get('/', async (_req, res) => {
  const medecins = await prisma.medecin.findMany()
  res.json(medecins)
})

export default router
