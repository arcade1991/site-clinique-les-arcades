import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

async function main() {
  await prisma.medecin.createMany({
    data: [
      { nom: 'Dupont', prenom: 'Jean', specialite: 'Cardiologue' },
      { nom: 'Martin', prenom: 'Claire', specialite: 'Dermatologue' },
      { nom: 'Ben Ali', prenom: 'Karim', specialite: 'Gynécologue' }
    ]
  })
}

main()
  .then(() => console.log('Seed completed'))
  .catch(e => console.error(e))
  .finally(async () => await prisma.$disconnect())
